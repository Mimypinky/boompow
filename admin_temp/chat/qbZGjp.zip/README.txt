A Pen created at CodePen.io. You can find this one at http://codepen.io/dope/pen/qbZGjp.

 Firstly I just wanna say sorry to CodePen. I may have inspected certain elements on CodePen and stole styles to match the styles on my pen - seriously, my bad.

I made a chat though. Maybe it would be cool to chat to your followers or whatever. Maybe it wouldn't.

2:20am and I'm feeling great though.

Cheers guys. Merry Christmas. Shout out to Coors Light (It really is a light beer).